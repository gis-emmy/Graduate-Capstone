@echo off
REM Start backend server and test endpoints

echo ========================================
echo TDOT Backend Server & API Test
echo ========================================

echo Starting Node.js server...
start "TDOT Backend" node server.js

REM Wait for server to start
timeout /t 3 /nobreak

echo.
echo Running API tests...
node test-api.js

echo.
pause
