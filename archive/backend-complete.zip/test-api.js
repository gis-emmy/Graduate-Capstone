#!/usr/bin/env node
/**
 * Quick API Test Script
 * Tests all endpoints and verifies responses
 */

const http = require('http');

function testEndpoint(path) {
  return new Promise((resolve) => {
    const options = {
      hostname: 'localhost',
      port: 3001,
      path: path,
      method: 'GET'
    };

    const req = http.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve({
            endpoint: path,
            status: res.statusCode,
            success: res.statusCode === 200,
            recordCount: json.count || json.data?.length || 0,
            data: json
          });
        } catch (e) {
          resolve({
            endpoint: path,
            status: res.statusCode,
            success: false,
            error: 'Invalid JSON'
          });
        }
      });
    });

    req.on('error', (error) => {
      resolve({
        endpoint: path,
        status: 0,
        success: false,
        error: error.message
      });
    });

    req.end();
  });
}

async function runTests() {
  console.log('\n' + '='.repeat(70));
  console.log('TDOT API Endpoint Test Suite');
  console.log('='.repeat(70) + '\n');

  const endpoints = [
    '/',
    '/api/health',
    '/api/projects',
    '/api/environmental-data',
    '/api/water-quality',
    '/api/biodiversity',
    '/api/watersheds',
    '/api/data-summary'
  ];

  let passed = 0;
  let failed = 0;

  for (const endpoint of endpoints) {
    process.stdout.write(`Testing ${endpoint.padEnd(30)}`);
    const result = await testEndpoint(endpoint);
    
    if (result.success) {
      console.log(`✓ ${result.status} (${result.recordCount} records)`);
      passed++;
    } else {
      console.log(`✗ ${result.status || 'ERR'} - ${result.error || 'Failed'}`);
      failed++;
    }
  }

  console.log('\n' + '='.repeat(70));
  console.log(`Test Results: ${passed} passed, ${failed} failed`);
  console.log('='.repeat(70) + '\n');

  process.exit(failed > 0 ? 1 : 0);
}

// Wait for server to be ready
setTimeout(runTests, 1000);
